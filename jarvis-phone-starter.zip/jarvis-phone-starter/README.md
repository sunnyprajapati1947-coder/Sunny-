# Personal Jarvis phone starter

Run in native Termux: python jarvis_personal.py --status
Terminal chat (after model is healthy): python jarvis_personal.py --chat
Phone browser page: python jarvis_personal.py --web   (open the printed 127.0.0.1 link on this phone)
Read JARVIS_PERSONAL_SETUP.md for model, approval, Hinglish/"Sunny ji", tasks, voice and troubleshooting steps.

Source code only: no model, secret, OAuth data, installed upstream runtime or chat is bundled.
Voice is OFF by default (/voice on). Android TTS voice gender depends on the installed engine.
All ten sources are cataloged, NOT all integrated/activated. Source downloads are explicit/pinned only.
Uses this Sunny repository's existing Nova security/tool boundary; upstream licenses/requirements are in jarvis_start.py.
