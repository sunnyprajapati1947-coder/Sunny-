# Personal Jarvis phone starter

Run in native Termux: python jarvis_personal.py --status
Terminal chat (after model is healthy): python jarvis_personal.py --chat
Phone browser page: python jarvis_personal.py --web   (open the printed 127.0.0.1 link on this phone)
Auto-restart the browser page after crashes: bash automation/jarvis_web_keepalive.sh
Backup local brain on 127.0.0.1:8081 is optional; see JARVIS_PERSONAL_SETUP.md.
Optional per-question cloud answer: /ask-cloud QUESTION, then /confirm TOKEN (key is set in Termux, never in chat).
Read JARVIS_PERSONAL_SETUP.md for model, approval, Hinglish/"Sunny ji", tasks, voice and troubleshooting steps.

Source code only: no model, secret, OAuth data, installed upstream runtime or chat is bundled.
Voice is OFF by default (/voice on). Android TTS voice gender depends on the installed engine.
All ten sources are cataloged, NOT all integrated/activated. Source downloads are explicit/pinned only.
Uses this Sunny repository's existing Nova security/tool boundary; upstream licenses/requirements are in jarvis_start.py.
