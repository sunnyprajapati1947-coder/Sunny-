# Personal Jarvis phone starter

Run in native Termux: python jarvis_personal.py --status
After loopback model is healthy: python jarvis_personal.py --chat
Read JARVIS_PERSONAL_SETUP.md for model, approval and permissions steps.

Source code only: no model, secret, OAuth data, installed upstream runtime or chat is bundled.
All ten sources are cataloged, NOT all integrated/activated. Source downloads are explicit/pinned only.
Uses this Sunny repository's existing Nova security/tool boundary; upstream licenses/requirements are in jarvis_start.py.
