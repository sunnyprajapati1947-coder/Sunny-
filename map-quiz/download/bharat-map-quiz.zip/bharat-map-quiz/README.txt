Bharat Map Quiz — installable web app
====================================

This folder is a complete offline web app. Two ways to run it:

1. Quick look
   Double-click index.html. Some browsers (Chrome on desktop) restrict storage and the
   service worker on file:// URLs, so progress may not be saved between reloads.

2. Proper install (recommended)
   Serve the folder over HTTP and open it on your phone:
       python3 -m http.server 8080
   Then use the browser menu -> "Add to Home screen". It then runs full screen,
   offline, and keeps your progress.

Hosting: upload this folder to GitHub Pages, Netlify, Vercel or any static host.
For a Play Store build wrap it with bubblewrap (TWA) or Capacitor.

Map data: datta07/INDIAN-SHAPEFILES (MIT licence), derived from Census/LGD boundaries.
