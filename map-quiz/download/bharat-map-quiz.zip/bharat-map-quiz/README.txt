Bharat Map Quiz — the whole game in one file
============================================

HOW TO PLAY ON A LAPTOP / PC
  1. Unzip this folder.
  2. Double-click  index.html  (Windows, macOS, Linux — any browser).
     That is it: the complete quiz lives inside that one file. No server,
     no installation, no internet needed.
  3. If the browser asks what to do with the file, right-click index.html and
     choose "Open with" -> Chrome / Edge / Firefox.

ON AN ANDROID PHONE
  Use the APK instead (Bharat-Map-Quiz.apk from the same download page).
  An APK is an Android app — it cannot run on a laptop or PC.
  On an iPhone, open this index.html in Safari and use Share -> Add to Home Screen.

PLAYING OFFLINE
  index.html needs no network at all. Progress is saved in the browser storage
  of whichever device you play on.

HOSTING (optional)
  Upload this folder to any static host (GitHub Pages, Netlify, Vercel) and the
  page also installs as an app via "Add to Home screen" — manifest.webmanifest
  and sw.js are included for that.

Map data: datta07/INDIAN-SHAPEFILES (MIT licence), derived from Census/LGD boundaries.
