/* UI copy — English. Every key here is used by app.js. */

const STRINGS = {
  appName: "Bharat Map Quiz",
  tagline: "Learn India on the map",

  // home
  helloMorning: "Good morning!",
  helloDay: "Hello!",
  helloEvening: "Good evening!",
  helloNight: "Good night!",
  homeHeadlineStart: "Learn the map of India",
  homeHeadlineProgress: (n) => `${n} of 36 states memorised`,
  level: "Level",
  daily: "Daily Challenge",
  dailySub: "10 mixed questions · same for everyone today",
  dailyDone: "Completed today",
  dailyPlay: "Play",
  dailyAgain: "See result",
  region: "Region",
  modes: "Play",
  extraModes: "Challenge yourself",
  learn: "Learn the map",
  learnSub: "Tap any state for capital + facts",
  stats: "Progress",

  // modes
  locate: "Find the state",
  locateSub: "A name is given — tap it on the map",
  identify: "Identify the shape",
  identifySub: "Which state is highlighted?",
  capital: "Capitals",
  capitalSub: "Match states with their capitals",
  neighbours: "Neighbours",
  neighboursSub: "Which state shares a border?",
  timed: "Timed blitz",
  timedSub: "10 seconds per question",
  challenge: "Survival",
  challengeSub: "3 lives · endless questions",
  sprint: "Speed run",
  sprintSub: "Every state, against the clock",
  weak: "Weak spots",
  weakSub: "Practise the states you miss",

  questions10: "10 Q",
  questions12: "12 Q",
  allStates: "All states",

  // quiz
  question: "Question",
  score: "Score",
  streak: "Streak",
  lives: "Lives",
  time: "Time",
  tapState: "Tap the state on the map",
  whichState: "Which state is this?",
  capitalOf: (name) => `What is the capital of ${name}?`,
  stateOfCapital: (name) => `Which state has ${name} as its capital?`,
  whereIs: (name) => `Where is ${name}?`,
  neighbourOf: (name) => `Which state shares a border with ${name}?`,
  hint: "Hint",
  skip: "Skip",
  next: "Next",
  finish: "Finish",
  hintUsed: "Hint used (−4 XP)",
  hintRegion: (region) => `Hint: it is in ${region} India`,
  hintFirstLetter: (letter) => `Hint: its name starts with "${letter}"`,
  timesUp: "Time's up!",
  correct: "Correct!",
  notQuite: (name) => `Not quite — it was ${name}`,
  tapOnMap: "Tap somewhere on the map",
  listen: "Listen",

  // result
  roundComplete: "Round complete!",
  perfect: "Perfect round!",
  survivalOver: "Survival over",
  sprintComplete: "Whole map done!",
  correctAnswers: "Correct",
  xpEarned: "XP earned",
  bestStreak: "Best streak",
  accuracy: "Accuracy",
  review: "Review answers",
  missed: "You missed",
  playAgain: "Play again",
  practiceWeak: "Practise weak states",
  home: "Home",
  share: "Share result",
  shared: "Result copied — paste it anywhere!",
  newBest: "New personal best!",

  // learn
  learnHint: "Tap any state to see its capital and a fact",
  labelsStates: "States",
  labelsCapitals: "Capitals",
  labelsOff: "Off",
  stateSearch: "All states & UTs",
  search: "Search a state or capital…",
  noResults: "Nothing found",
  state: "State",
  ut: "Union Territory",
  capitalLabel: "Capital",
  factLabel: "Remember this",
  quizThis: "Quiz this state",
  memorised: "Memorised",
  masteredLegend: "Memorised",
  close: "Close",

  // stats
  progressTitle: "Your progress",
  memorisedStates: "States memorised",
  totalAnswers: "Answers",
  bestSprint: "Best sprint",
  achievements: "Achievements",
  achievementsCount: (a, b) => `${a} of ${b} unlocked`,
  byRegion: "Mastery by region",
  byState: "State by state",
  noData: "Play a round to start tracking",
  resetProgress: "Reset all progress",
  resetAsk: "This deletes all XP, streaks and achievements. Continue?",
  resetDone: "Progress reset",

  // settings
  settings: "Settings",
  sound: "Sound effects",
  on: "On",
  off: "Off",
  stateNames: "State names",
  english: "English",
  hindi: "हिंदी",
  download: "Download the app",
  downloadSub: "Offline single-file build + installable package",
  downloadFile: "Download single file (.html)",
  downloadZip: "Download app package (.zip)",
  install: "Install on this device",
  installHint: "Use your browser menu → “Add to Home screen”. Works offline afterwards.",
  installNow: "Install",
  about: "About",
  aboutText:
    "Made for learning: tap the map until the shapes stick. Map boundaries from the Census/LGD shapefile published in datta07/INDIAN-SHAPEFILES (MIT). Everything runs on your device — no accounts, no ads, no tracking.",
  credits: "Map data: datta07/INDIAN-SHAPEFILES (MIT) · 28 states + 8 UTs",
  back: "Back",
};

export function t(key, ...args) {
  const value = STRINGS[key];
  if (value === undefined) return key;
  return typeof value === "function" ? value(...args) : value;
}

export const settings = STRINGS;

/** Speech synthesis locale: English UI, Hindi only for optional Hindi names. */
export function langCode(stateNames = "en") {
  return stateNames === "hi" ? "hi-IN" : "en-IN";
}
